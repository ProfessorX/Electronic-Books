#!/bin/sh

PRODUCT=`/bin/kobo_config.sh`;
[ $PRODUCT != trilogy ] && PREFIX=$PRODUCT-

i=0;
flag=0;
while true; do
        i=$((((i + 1)) % 11));
        zcat /etc/images/$PREFIX\on-$i.raw.gz | /usr/local/Kobo/pickel showpic 1;
        usleep 250000;
        if [ $flag -eq 0 ]; then
            if [ -e /mnt/onboard/.kobo/on_start.sh ]; then
                /mnt/onboard/.kobo/on_start.sh &
                flag=1;
            fi
        fi
done 
