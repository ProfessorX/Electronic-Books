$root/.kobo/fmon/fmon $root/reboot.png $root/.kobo/KoboLauncher/utils/reboot.sh >> $root/.kobo/fmon/fmon.log.txt 2>&1 &
