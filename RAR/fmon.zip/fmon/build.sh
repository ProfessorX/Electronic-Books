#!/bin/sh

g++ fmon.cpp -o fmon

