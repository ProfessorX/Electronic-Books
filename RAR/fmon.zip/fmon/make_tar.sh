#!/bin/sh

tar zcvf KoboRoot.tgz etc mnt
