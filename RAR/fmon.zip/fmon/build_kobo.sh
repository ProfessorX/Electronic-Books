#!/bin/sh

/opt/gcc-linaro-kobo/bin/arm-linux-gnueabihf-g++ fmon.cpp -o fmon

